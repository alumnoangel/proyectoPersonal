export interface Grafica {
    marca: string;
    ensamblador: string;
    modelo: string;
    precio: number;
    memoria: number;
    foto: string;
}
